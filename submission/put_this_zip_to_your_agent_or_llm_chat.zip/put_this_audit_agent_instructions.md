# Agent / LLM execution instructions — EPGSpeller (IEEE SLT 2026)

**Assume the entire zip is uploaded to your session.** Start at `put_this_zip_to_your_agent_or_llm_chat.md`.

The main paper PDF is not in this zip and remains self-contained without it.

## Required read order

1. `put_this_zip_to_your_agent_or_llm_chat.md`
2. `put_this_audit_reviewer_FAQ.yaml`
3. `put_this_audit_claim_trace.md`
4. `put_this_audit_evidence_manifest.yaml`
5. `put_this_audit_deferred_experiments.yaml`
6. All bundled `tables/`, `reports/`, and audit subdirs

Optional: `supplement.pdf` — prefer CSV/YAML for verification.

## Rules

- Do not infer numbers absent from bundled artifacts.
- Read deferred experiments before flagging missing work as undisclosed.
- This zip does not extend the paper page limit.

## Expected output

Verified traceability, or a concrete mismatch/over-claim list with file paths and row IDs.
